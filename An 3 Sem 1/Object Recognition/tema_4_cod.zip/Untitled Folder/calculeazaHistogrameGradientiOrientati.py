import numpy as np
import cv2
from numpy.linalg import norm

from genereazaPuncteCaroiaj import genereazaPuncteCaroiaj


def calculeazaHistogrameGradientiOrientati(img, puncte, dimensiuneCelula):
    # calculeaza pentru fiecare punct din de pe caroiaj, histograma de gradienti orientati
    # corespunzatoare dupa cum urmeaza:
    #  - considera cele 16 celule inconjuratoare si calculeaza pentru fiecare
    #  celula histograma de gradienti orientati de dimensiune 8
    #  - concateneaza cele 16 histograme de dimeniune 8 intr-un descriptor de
    #  lungime 128 = 16*8
    #  - fiecare celula are dimensiunea dimensiuneCelula x dimensiuneCelula (4x4 pixeli)
    #
    # Input:
    #       img - imaginea input
    #    puncte - puncte de pe caroiaj pentru care calculam histograma de
    #             gradienti orientati
    #   dimensiuneCelula - defineste cat de mare este celula
    #                    - fiecare celula este un patrat continand
    #                      dimensiuneCelula x dimensiuneCelula pixeli
    # Output:
    #        descriptoriHOG - matrice #Puncte X 128
    #                       - fiecare linie contine histograme de gradienti
    #                        orientati calculata pentru fiecare punct de pe
    #                        caroiaj
    #               patchuri - matrice #Puncte X (16 * dimensiuneCelula^2)
    #                       - fiecare linie contine pixelii din cele 16 celule
    #                         considerati pe coloana

    nBins = 8  # dimensiunea histogramelor fiecarei celule

    descriptoriHOG = np.zeros(
        [len(puncte),
         nBins * 4 * 4])  # fiecare linie reprezinta concatenarea celor 16 histograme corespunzatoare fiecarei celule
    patchuri = np.zeros([len(puncte), 4 * dimensiuneCelula * 4 * dimensiuneCelula])  #

    # print (descriptoriHOG.shape)
    # print (patchuri.shape)

    if np.shape(img)[2] == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


    patch_size = 16



    index = 0
    for punct in puncte:
        patch = img[punct[0] - patch_size / 2:punct[0] + patch_size / 2,
                punct[1] - patch_size / 2:punct[1] + patch_size / 2]

        patchuri[index, :] = patch.ravel()
        hist = hog(patch)
        descriptoriHOG[index, :] = hist

        # cv2.imshow('image', patch)
        # cv2.waitKey(0)
        index += 1

    return descriptoriHOG, patchuri





def hog(img):
    gx = cv2.Sobel(img, cv2.CV_32F, 1, 0)
    gy = cv2.Sobel(img, cv2.CV_32F, 0, 1)
    mag, ang = cv2.cartToPolar(gx, gy)
    bin_n = 8  # Number of bins
    bin = np.int32(bin_n * ang / (2 * np.pi))

    bin_cells = []
    mag_cells = []

    cellx = celly = 4

    for i in range(0, img.shape[0] / celly):
        for j in range(0, img.shape[1] / cellx):
            bin_cells.append(bin[i * celly: i * celly + celly, j * cellx: j * cellx + cellx])
            mag_cells.append(mag[i * celly: i * celly + celly, j * cellx: j * cellx + cellx])

    hists = [np.bincount(b.ravel(), m.ravel(), bin_n) for b, m in zip(bin_cells, mag_cells)]
    hist = np.hstack(hists)

    # transform to Hellinger kernel
    eps = 1e-7
    hist /= hist.sum() + eps
    hist = np.sqrt(hist)
    hist /= norm(hist) + eps

    return hist


img = cv2.imread('/home/calin/Desktop/Proiect4/core/data/masini-exempleAntrenare-pozitive/pos_image_0001.png')
puncte = genereazaPuncteCaroiaj(img, 5, 5, 16)
calculeazaHistogrameGradientiOrientati(img, puncte, dimensiuneCelula=4)
