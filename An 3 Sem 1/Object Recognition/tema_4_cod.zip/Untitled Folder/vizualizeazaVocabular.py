import numpy as np
import cv2
from imutils import build_montages

def vizualizeazaVocabular(cuvinteVizuale, descriptoriHOG, patches, dimensiuneCelula):
    # vizualizeaza patch-urile extrase din imagini care corespund cel mai bine 
    # cuvintelor vizuale ce alcatuiesc vocabularul

    latimePatch = 4 * dimensiuneCelula
    inaltimePatch = 4 * dimensiuneCelula

    clusterPatches = np.zeros([inaltimePatch, latimePatch, 1, 0])
    scores = np.zeros([0, 0])

    # lipseste functia gasesteCorespondent
    [idx, dist] = gasesteCorespondente(descriptoriHOG, cuvinteVizuale)

    # afla patch-ul cel mai apropiat de cuvantulVizual curent
    for i in range(0, cuvinteVizuale.shape[0]):

        matching = np.nonzero(idx == i)

        if matching:
            [d, smallest] = min(dist(matching))
            closestIdx = matching(smallest)

            p = np.reshape(patches[closestIdx, :], inaltimePatch, latimePatch, 1)
            # clusterPatches[:, :, :, end + 1] = p
            clusterPatches = np.append(clusterPatches,p)
            scores = np.append(scores, len(matching))
            # scores[end + 1] = len(matching)

    [sortedScores, scoreOrder] = - np.sort(-scores)
    clusterPatches = clusterPatches[:, :, :, scoreOrder]

    montages = build_montages(clusterPatches, (128, 196), (7, 3))

    for montage in montages:
        cv2.imshow("Montage", montage)
        cv2.waitKey(0)

    # montage(clusterPatches, 'DisplayRange', [])
