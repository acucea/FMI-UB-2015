def calculeazaHistogramaBOVW(descriptoriHOG, cuvinteVizuale):
  # calculeaza histograma BOVW pe baza descriptorilor si a cuvintelor
  # vizuale, gasind pentru fiecare descriptor cuvantul vizual cel mai
  # apropiat (in sensul distantei Euclidiene)
  #
  # Input:
  #   descriptori: matrice MxD, contine M descriptori de dimensiune D
  #   cuvinteVizuale: matrice NxD, contine N centri de dimensiune D 
  # Output:
  #   histogramaBOVW: vector linie 1xN 
  
 # completati codul
  histogramaBOVW = None
  return histogramaBOVW
    