#
# Tema 4 - Clasificarea Imaginilor folosind modelul Bag-of-Visual-Words
# 
#
##
#ANTRENARE
import numpy as np
from clasificaBOVW import clasificaBOVW
from calculeazaHistogrameBOVW_director import calculeazaHistogrameBOVW_director
from construiesteVocabular import construiesteVocabular
from clasificaBOVWCelMaiApropiatVecin import clasificaBOVWCelMaiApropiatVecin
from clasificaSVM import clasificaSVM


print('Etapa de antrenare')
print('Construim vocabularul de cuvinte vizuale')

k = 5# k = numarul de cuvinte vizuale ale vocabularului
iterMax = 50

# cuvintele vizuale sunt centri clusterilor obtinuti prin k-means
# se obtin prin apelarea functiei construiesteVocabular
cuvinteVizuale = construiesteVocabular('../data/masini-exempleAntrenare-pozitive+negative',k,iterMax)
# 
print('Procesam imaginile de antrenare pozitive (contin masini)')
histogrameBOVW_exemplePozitive = calculeazaHistogrameBOVW_director('../data/masini-exempleAntrenare-pozitive',cuvinteVizuale)
print('Procesam imaginile de antrenare negative (NU contin masini)')
histogrameBOVW_exempleNegative = calculeazaHistogrameBOVW_director('../data/masini-exempleAntrenare-negative',cuvinteVizuale)

##
#TESTARE
print('Etapa de testare')
print('Procesam imaginile de testare pozitive (contin masini)')
histogrameBOVW_exemplePozitive_test = calculeazaHistogrameBOVW_director('../data/masini-exempleTestare-pozitive',cuvinteVizuale)
print('Procesam imaginile de testare negative (NU contin masini)')
histogrameBOVW_exempleNegative_test = calculeazaHistogrameBOVW_director('../data/masini-exempleTestare-negative',cuvinteVizuale)

nrExemplePozitive = np.shape(histogrameBOVW_exemplePozitive_test)[0]
nrExempleNegative = np.shape(histogrameBOVW_exempleNegative_test)[1]

histogrameBOVW_test = [histogrameBOVW_exemplePozitive_test, histogrameBOVW_exempleNegative_test]
etichete_test = [np.ones(nrExemplePozitive,1), np.zeros(nrExempleNegative,1)]

print('______________________________________')
print('Clasificator Cel Mai Apropiat Vecin')
clasificaBOVW(histogrameBOVW_test, etichete_test, histogrameBOVW_exemplePozitive, histogrameBOVW_exempleNegative, clasificaBOVWCelMaiApropiatVecin)
print('______________________________________')
print('Clasificator SVM linear')
clasificaBOVW(histogrameBOVW_test, etichete_test, histogrameBOVW_exemplePozitive, histogrameBOVW_exempleNegative, clasificaSVM)
print('______________________________________')
