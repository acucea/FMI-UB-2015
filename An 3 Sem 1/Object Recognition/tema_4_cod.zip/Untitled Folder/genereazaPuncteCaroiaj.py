import cv2
import numpy as np


def genereazaPuncteCaroiaj(img, nrPuncteX, nrPuncteY, margine):
    # genereaza puncte pe baza unui caroiaj
    # un caroiaj este o retea de drepte orizontale si verticale de forma urmatoare:
    #
    #        |   |   |   |
    #      --+---+---+---+--
    #        |   |   |   |
    #      --+---+---+---+--
    #        |   |   |   |
    #      --+---+---+---+--
    #        |   |   |   |
    #      --+---+---+---+--
    #        |   |   |   |
    #
    # Input:
    #       img - imaginea input
    #       nrPuncteX - numarul de drepte verticale folosit la constructia caroiajului
    #                 - in desenul de mai sus aceste drepte sunt identificate cu simbolul |
    #       nrPuncteY - numarul de drepte orizontale folosit la constructia caroiajului
    #                 - in desenul de mai sus aceste drepte sunt identificate cu simbolul --
    #         margine - numarul de pixeli de la marginea imaginii (sus, jos, stanga, dreapta) pentru care nu se considera puncte
    # Output:
    #       puncteCaroiaj - matrice (nrPuncteX * nrPuncteY) X 2
    #                     - fiecare linie reprezinta un punct (y,x) de pe caroiaj aflat la intersectia dreptelor orizontale si verticale
    #                     - in desenul de mai sus aceste puncte sunt idenficate cu semnul +

    puncteCaroiaj = np.zeros([nrPuncteX * nrPuncteY, 2])

    puncteX = np.linspace(margine, img.shape[0] - margine, nrPuncteX)
    puncteY = np.linspace(margine, img.shape[1] - margine, nrPuncteY)

    puncteX = np.around(puncteX).astype(int)
    puncteY = np.around(puncteY).astype(int)

    puncteCaroiaj = [[x0, y0] for x0 in puncteX for y0 in puncteY]

    # print puncteCaroiaj

    # completati codul

    return puncteCaroiaj


# img = cv2.imread('/home/calin/Desktop/Proiect4/core/data/masini-exempleAntrenare-pozitive/pos_image_0001.png')
# genereazaPuncteCaroiaj(img, 3, 3, 5)
# print (img.shape)
#
# cv2.imshow('image', img)
# cv2.waitKey(0)
