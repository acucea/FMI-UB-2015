import numpy as np


def kmeans_iter(X, K, iterMax):
    # implementeaza algoritmul k-means
    #
    # Input:
    #        X - N x d, X contine pe fiecare linie un vector de caracteristici, N puncte d-dimensionale
    #        K - numarul de clusteri
    #  iterMax - numarul maxim de iteratii
    # Output:
    #        C - contine clusterii, o matrice K x d, fiecare linie contine un cluster
    #        etichetare - vector coloana N x 1, care specifica carui cluster
    #                     apartine fiecare punct din X
    X = np.array(X).astype(np.double)

    N, d = X.shape

    # Initializam centri clusterilor = puncte din X alese aleator diferite
    permutare = np.random.permutation(N)
    C = X[permutare[1:K], :]

    # etichetare initiala
    etichetare = np.zeros([N, 1])

    # algoritmul iterativ propriu-zis
    iter = 0
    while True:
        iter = iter + 1
        print ('iteratia = {}'.format(str(iter)))

        # determina apartenenta fiecarui punct din X la un cluster
        etichetareOptima = np.zeros([N, 1])
        distantaMinima = np.inf * np.ones([N, 1])
        for k in range(0, K-1):
            for n in range(0, N-1):
                # distanta Euclidiana
                distanta = sum((X[n, :] - C[k, :]) ** 2)
                if distanta < distantaMinima[n]:
                    distantaMinima[n] = distanta
                    etichetareOptima[n] = k

        # iesi din while daca nu s-au schimbat centri
        if all(etichetareOptima == etichetare) or (iter == iterMax):
            if all(etichetareOptima == etichetare) :
                print ('Eticheta optima')
            else:
                print ('Iteratie maxima')

            break

        etichetare = etichetareOptima

        # determina centri noilor clusteri pe baza punctelor
        for k in range(0, K-1):
            points = [X[j] for j in range(len(X)) if etichetareOptima[j] == k]
            C[k, :] = np.mean(points, axis=0)

    return [C, etichetare]
